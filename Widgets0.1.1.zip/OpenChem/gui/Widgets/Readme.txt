Widgets 0.1
john.michelsen@gte.net
http://www2.zyvex.com/OpenChem/index.htm

needs Python MegaWidgets (Pmw), available from http://www.dscpl.com.au/pmw/

FlatButtons    	raise when you hover over them    
iconPath		set path to icon directory
MDI       		Mutliple Document Interface
ProgressBar		progress by percentage or ticks
Toolbar		dockable toolbars
Tree 			tree with default icons from MS's Windows Explorer

Help with copying Mac and Unix styles for the child windows is needed.
(I only have a windows box).

John

